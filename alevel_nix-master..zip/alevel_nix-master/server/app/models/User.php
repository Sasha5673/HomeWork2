<?php

namespace app\models;

use frameworkVendor\core\Db;
use frameworkVendor\core\base\Model;


class User extends Model
{
    public $table = 'users';

    public function insertUser($firstName,$email, $password)
   {
           $password = md5($password);

           $sql = "INSERT INTO users (firstName,email, password)
        values('$firstName', '$email', '$password')";
           $this->pdo->query($sql);
               return true;

    }


    public function emailAlreadyExists($email)
    {
        $sql = "SELECT * FROM `users` WHERE `email` = '$email'";
        return $this->pdo->query($sql);
    }


    public function autoregUser($email, $password){
        $password = md5($password);
        $sql = "SELECT * FROM  users WHERE email = '$email' AND password = '$password'";

        return $this->pdo->query($sql);

    }

}