<?php


namespace app\models;

use frameworkVendor\core\base\Model;

class Main extends Model
{
    public $table = 'posts';
}