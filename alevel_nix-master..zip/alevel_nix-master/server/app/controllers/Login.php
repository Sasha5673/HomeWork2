<?php

namespace app\controllers;

use frameworkVendor\core\base\Controller;
use \app\models\User;


class Login extends Controller
{
    public function __construct($route)
    {
        parent::__construct($route);
    }

    public function index()
    {
        $title = 'Login';
        $this->set(compact('title'));
    }

    public function singin()
    {
        $title = 'singin';

        $this->set(compact('title'));
    }

    public function register()
    {
        $title = 'register';
        $this->set(compact('title'));
    }

    public function save()
    {
        $titleReg = '';
        $model = new User;
        if($model->emailAlreadyExists($_POST['email'])){
            $_SESSION['message'] = 'Пользователь с таким email уже существует!';
            header('Location: ../register.php');
            die();
        }
        $res = $model->insertUser($_POST['firstName'], $_POST['email'], $_POST['password']);
        if ($res) {
            $titleReg = "Вы зарегались";
        } else{
            $titleReg = 'Error';
        }
        $this->set(compact('titleReg'));
    }

    public function cheak()
    {

        $titleAuto = '';
        $model = new User;
        $result = $model->autoregUser($_POST['email'], $_POST['password']);
        if ($result == false) {
            $_SESSION['message'] = 'Неверный email или пароль';
            header('Location: ..\singin.php');
        }
        else{
            $titleAuto = 'Вы успешно авторизовались';
            $users = $model->findOne($_POST['email'],'email');
        }


        $this->set(compact('titleAuto','users'));
    }

    public function task()
    {
        $titleAutor = '';


        if (isset($_POST['docs'])) {$docs= $_POST['docs'];}
        $triad = $_POST['triad'];//расширение файла

        $fh = fopen("mydata.txt",'w+');//колличество файлов
        $i = fgets($fh);
        fputs($fh, $i++);
        fclose($fh);
        $file = $i."".$triad;
        $Saved_file = fopen($file, 'w+');
        fwrite($Saved_file, "По сосотаву документация: ".$docs);

        fclose($Saved_file);

        $titleAutor ="Запись в файл: " . $docs;
        $this->set(compact('titleAutor'));
        }


    public function logout()
    {
        header("Location: \singin");
    }


}