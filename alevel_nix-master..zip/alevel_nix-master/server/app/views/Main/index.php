<h1><?= $title ?></h1>
<?php foreach ($posts as $item): ?>
    <div>
        <div><?= $item['id']?></div>
        <div><?= $item['title']?></div>
    </div>
   <hr>
<?php endforeach; ?>