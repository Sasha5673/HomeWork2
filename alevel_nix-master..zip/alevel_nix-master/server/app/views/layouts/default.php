<head>
    <title><?= $title ?></title>
</head>
<body>
<div>
    <header>
        <div>
            <div>
                <a href="/">Главная логотип</a>
            </div>
            <div>
                <a href="/login">Sign up</a>
            </div>
        </div>
    </header>
    <?= $content ?>
</div>
</body>