<head><link rel="stylesheet" href="css/style.css"></head>
<h1><?= $titleAuto ?></h1>
<?php foreach ($users as $item): ?>

    <div class="registration-cssave">
        <h4 class="text-center">Ваше имя:</h4>
        <div class="form-group"><?= $item['firstName']?></div>
        <h4 class="text-center">Ваша почта:</h4>
        <div class="form-group"><?= $item['email']?></div>

    <hr>
<?php endforeach; ?>


    <form name="gl" method="post" action= "/task"  >
        <h3>3. Для экспертизы были представлены следующие документы:</h3>
        <p>Введите запись в txt file:   </p>
        <input class="form-control item" Name="docs"  ROWS=2 COLS=20> </h3><br>
        <p>Введите название файла: </p>
        <input class="form-control item" name="triad"  ROWS=2 COLS=5><br>
        <br><TABLE BORDER CELLpadding="3">
            <tr>
                <td style="background-color:#cc0000; color:#ffffff">
                    <p><input type="submit" value="SAVE" width="0"></table>

    </form>

<div class="form-group">
    <form action="/logout" method="post">
        <div>
            <button class="btn btn-primary btn-block create-account" type="submit">Logout</button>
        </div>
    </form>
</div>
</div>
