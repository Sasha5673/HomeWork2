<h1><?= $titleReg ?></h1>
<form action="/singin" method="post">
    <div>
        <h1>Нажмите на кнопку что бы авторизоваться</h1>
        <button type="submit">Авторизоваться</button>
    </div>
</form>