<head><link rel="stylesheet" href="css/style.css"></head>

<div class="registration-cssave">
<form action="/cheak" method="post">
    <h3 class="text-center">Авторизация</h3>
    <div class="form-group">
    <input class="form-control item" id="email" type="email" name="email" placeholder="Email">
    </div>
        <div class="form-group">
    <input class="form-control item" id="password" type="password" name="password" placeholder="Password">
        </div>
    <div class="form-group">
    <button class="btn btn-primary btn-block create-account" type="submit">Singin</button>
    </div>
    <p
    <?php
    if (!empty($_SESSION['message'])) {
        echo '<p class="msg"> ' . $_SESSION['message'] . ' </p>';
    }
    unset($_SESSION['message']);
    ?>
</form>
    <form action="/register">
        <div class="form-group">
            <strong><p>У вас нет аккаунта? -</p></strong>
            <button class="btn btn-primary btn-block create-account" type="submit">Регистрация</button>
        </div>
    </form>
</div>


