<?php
header('Location: ../singin.php');
?>
