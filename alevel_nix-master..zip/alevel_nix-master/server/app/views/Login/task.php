<head><link rel="stylesheet" href="css/style.css"></head>

<div class="registration-cssave">

<h1 class="text-center"><?= $titleAutor ?></h1>
<form action="/singin" method="post">
    <div>
        <button class="btn btn-primary btn-block create-account" type="submit">Logout</button>
    </div>
</form>
</div>