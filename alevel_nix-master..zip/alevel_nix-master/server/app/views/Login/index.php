
<head>
    <title><?= $title ?></title>
    <title><?= $titleM ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="registration-cssave">
    <header>
        <div class="form-group">
            <form action="/singin" method="post">
                <div class="form-group">
                <button class="btn btn-primary btn-block create-account" type="submit" >Signin</button>
            </div>
            </form>
            <form action="/register" method="post">
            <div class="form-group">
                <button class="btn btn-primary btn-block create-account" type="submit" >Register</button>
            </div>
            </form>
        </div>
    </header>

</div>
</body>