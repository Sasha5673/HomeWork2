<head><link rel="stylesheet" href="css/style.css"></head>
<h1><?= $title ?></h1>
<div class="registration-cssave">
<form action="/save" method="post">
    <h3 class="text-center">Регистрация</h3>
    <div class="form-group">
        <input class="form-control item" type="text" name="firstName"  pattern="^[a-zA-Z0-9_.-]*$" id="username" placeholder="Ваше имя">
    </div>
    <div class="form-group">
        <input class="form-control item" type="email" name="email" id="email" placeholder="Email">
    </div>
    <div class="form-group">
        <input class="form-control item" type="password" name="password" id="password" placeholder="Password">
    </div>

    <div class="form-group">
        <button class="btn btn-primary btn-block create-account" type="submit">Зарегестрироваться</button>
    </div>

    <?php
    if (!empty($_SESSION['message'])) {
        echo '<p class="msg"> ' . $_SESSION['message'] . ' </p>';
    }
    unset($_SESSION['message']);
    ?>

</form>


<form action="/singin">
    <div class="form-group">
        <strong><p>У вас уже есть аккаунт? -</p></strong>
        <button class="btn btn-primary btn-block create-account" type="submit">Авторизация</button>
    </div>
</form>
</div>