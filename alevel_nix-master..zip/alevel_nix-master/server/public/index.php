<?php
use frameworkVendor\core\Router;
session_start();

error_reporting(-1);

$query = rtrim($_SERVER['QUERY_STRING'], '/');

define('LAYOUT', 'default');

spl_autoload_register(function ($class){
    $file = dirname(__DIR__) . '/' . str_replace('\\', '/', $class) . '.php';
    if (is_file($file)){
        require_once $file;
    }
});

Router::add('^$', ['controller' => 'Main', 'action' => 'index']);

Router::add('^login', ['controller' => 'Login', 'action' => 'index']);
Router::add('^singin', ['controller' => 'Login', 'action' => 'singin']);
Router::add('^register', ['controller' => 'Login', 'action' => 'register']);
Router::add('^save', ['controller' => 'Login', 'action' => 'save']);
Router::add('^cheak', ['controller' => 'Login', 'action' => 'cheak']);
Router::add('^task', ['controller' => 'Login', 'action' => 'task']);
Router::add('^logout', ['controller' => 'Login', 'action' => 'logout']);



Router::dispatch($query);